// controllers/userController.js

const bcrypt = require('bcryptjs'); // Import bcryptjs for password hashing
const { User, Page } = require('../models');
const jwt = require('jsonwebtoken')

exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.findAll();
    res.json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.createUser = async (req, res) => {
  try {
    const { username, password, role } = req.body;
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ message: 'Authorization header missing' });
    }
    const token = authHeader.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'JWT token missing' });
    }
    // const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Check if the user has an admin role from the token obtained during login
    // if (role === 'admin' || role ==='user') {
    //   // Ensure the role provided in the request body is valid
    //   const validRoles = ['admin', 'user'];
    //   if (!validRoles.includes(role)) {
    //     return res.status(400).json({ message: 'Invalid role' });
    //   }

      // Hash the password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create the new user
      const newUser = await User.create({ username, password: hashedPassword, role });
      res.status(201).json(newUser);

  } catch (error) {
    console.error('Error creating user:', error); // Log the error
    if (error instanceof jwt.JsonWebTokenError) {
      return res.status(401).json({ message: 'Invalid JWT token' });
    }
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const { username, password, role } = req.body;
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    // Hash the password if provided
    let hashedPassword;
    if (password) {
      hashedPassword = await bcrypt.hash(password, 10);
    }
    await user.update({ username, password: hashedPassword, role });
    res.json(user);
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    await user.destroy();
    res.status(200).json({ message: "User deleted successfully" });
    res.status(204).end();
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.assignRoleToUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const { role } = req.body;
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    user.role = role;
    await user.save();
    res.json(user);
  } catch (error) {
    console.error('Error assigning role to user:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.createPage = async (req, res) => {
  try {
    const { name, content, roleId } = req.body;

    // Check if roleId is provided
    if (!roleId) {
      return res.status(400).json({ message: 'roleId is required' });
    }

    // Check if the user with the provided roleId exists
    const user = await User.findByPk(roleId);
    if (!user) {
      return res.status(404).json({ message: 'User with the provided roleId not found' });
    }

    // Create the page with the provided roleId
    const page = await Page.create({ name, content, roleId });
    res.status(201).json(page);
  } catch (error) {
    console.error('Error creating page:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

