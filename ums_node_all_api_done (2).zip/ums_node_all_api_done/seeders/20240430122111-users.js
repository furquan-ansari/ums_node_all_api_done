'use strict';

const bcrypt = require('bcryptjs'); // Import bcryptjs library

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    // Hash the password using bcrypt
    const hashedPassword = await bcrypt.hash('admin', 10); // 10 is the salt rounds

    await queryInterface.bulkInsert('users', [
      {
        username: "admin",
        password: hashedPassword, // Store the hashed password
        role: "admin",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    // Delete the user with username "admin"
    await queryInterface.sequelize.transaction(async (transaction) => {
      await queryInterface.sequelize.query(
        `DELETE FROM users WHERE username = 'admin'`,
        { transaction }
      );
    });
  }
};
