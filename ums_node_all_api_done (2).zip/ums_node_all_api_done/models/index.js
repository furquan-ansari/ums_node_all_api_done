// models/index.js

const Sequelize = require('sequelize');
const sequelize = new Sequelize('ums_node', 'root', 'root', {
  host: 'localhost',
  dialect: 'mysql',
});

const User = sequelize.define('User', {
  username: Sequelize.STRING,
  password: Sequelize.STRING,
  role: Sequelize.STRING,
  // Add other user attributes as needed
});

const Page = sequelize.define('Page', {
  name: Sequelize.STRING,
  content: Sequelize.TEXT,
  roleId: Sequelize.INTEGER,
});

// Define association between User and Page
User.hasMany(Page, { foreignKey: 'roleId' });
Page.belongsTo(User, { foreignKey: 'roleId' });

// Automatically create tables in the database
sequelize.sync()
  .then(() => {
    console.log('Database synced successfully');
  })
  .catch((error) => {
    console.error('Error syncing database:', error);
  });

module.exports = { sequelize, User, Page };
