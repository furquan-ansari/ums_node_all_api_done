// import logo from './logo.svg';
// import './App.css';

import Signin from "./components/login";

function App() {
  return (<Signin /> );
}

export default App;
