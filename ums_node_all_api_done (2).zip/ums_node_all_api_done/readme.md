# To run code 

<!-- npm run dev -->

# To data seed for admin

<!-- npx sequelize-cli db:seed:all  -->

# To undo data seed for admin

 <!-- npx sequelize-cli db:seed:undo -->