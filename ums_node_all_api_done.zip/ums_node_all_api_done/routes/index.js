// routes/index.js

const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const authController = require('../controllers/authController');
const userController = require('../controllers/userController');

const isAdmin = (req, res, next) => {
  const token = req.headers.authorization.split(' ')[1];
  if (!token) {
    return res.status(403).json({ message: 'Forbidden: No token provided' });
  }

  // Verify token
  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ message: 'Forbidden: Invalid token / May be token already expired' });
    }
    console.log(decoded);
    const { username } = decoded;


    // Check if user is authorized as an admin
    if (username !== 'admin') {
      return res.status(403).json({ message: 'Forbidden: User is not authorized as an admin' });
    }
    console.log(username);
    // User is authorized as an admin, proceed to the next middleware
    next();
  });
};

router.post('/login', authController.login);
router.get('/users', isAdmin, userController.getAllUsers);
router.post('/users', isAdmin, userController.createUser); // Only admin can create users
router.put('/users/:userId', isAdmin, userController.updateUser);
router.delete('/users/:userId', isAdmin, userController.deleteUser);
router.post('/users/:userId/roles', isAdmin, userController.assignRoleToUser);
router.post('/pages', isAdmin, userController.createPage);

module.exports = router;
